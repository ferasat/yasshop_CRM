<?php $__env->startSection('title' , 'انبار'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">

            <div class="col-md-9">

                <div class="card" style="">
                    <h5 class="card-header">موجودی انبار </h5>

                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">
                            <strong> موجودی واقعی کل محصولات : </strong><?php echo e($total_inventory); ?>

                        </li>
                        <li class="list-group-item">
                            <strong> ارزش مالی کالا ها (قیمت خرید) : </strong> <?php echo e($financial_cost_of_products); ?> تومان
                        </li>
                        <li class="list-group-item">
                            <strong> ارزش تک فروشی محصولات (موجود در انبار) : </strong> <?php echo e($sales_value_of_products); ?> تومان
                        </li>
                        <li class="list-group-item">
                            <strong> سود احتمالی تک فروشی محصولات (موجود در انبار) : </strong> <?php echo e($sales_value_of_products - $financial_cost_of_products); ?> تومان
                        </li>

                    </ul>
                    <div class="card-body">

                    </div>
                </div>

                <div class="card" style="top:10px;">
                    <h5 class="card-header"> کسری های انبار </h5>

                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">تعداد کسری انبار : <?php echo e($numberP); ?> عدد</li>
                    </ul>
                    <div class="card-body">
                        <table class="table table-bordered table-hover table-responsive">
                            <thead>
                            <tr>
                                <th>تصویر</th>
                                <th>کد محصول</th>
                                <th>نام محصول</th>
                                <th>موجودی</th>
                                <th>آینده تامین</th>
                            </tr>
                            </thead>
                            <tbody >
                            <?php echo $lessProducts; ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <?php echo $__env->make('admin.include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\MyWork\xampp\htdocs\cms\yasshop\resources\views/yasshop/warehousing/index.blade.php ENDPATH**/ ?>
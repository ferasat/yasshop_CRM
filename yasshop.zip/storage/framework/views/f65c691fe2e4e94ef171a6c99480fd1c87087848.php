<?php $__env->startSection('title' , 'لیست محصولات'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <ul class="nav nav-tabs card-header-tabs">
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(asset('/dashboard/orders/')); ?>">سفارشات</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link active" href="<?php echo e(asset('/dashboard/orders/new')); ?>">سفارش جدید</a>
                            </li>
                        </ul>
                    </div>

                    <div class="card-body">
                        <div class="row">
                            <div class="newCustomer">
                                <?php echo e($cart_id); ?> - <?php echo e($customer); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\MyWork\xampp\htdocs\cms\yasshop\resources\views/yasshop/order/listProductOrder.blade.php ENDPATH**/ ?>
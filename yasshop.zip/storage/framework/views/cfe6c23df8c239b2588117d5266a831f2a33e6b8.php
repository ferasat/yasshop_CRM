<?php $__env->startSection('title' , 'بررسی قیمت و موجودی کالا ها'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(asset(route('dashboard'))); ?>">پیشخوان</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(asset(route('warehousing'))); ?>">انبار</a></li>
                <li class="breadcrumb-item active" aria-current="page">بررسی قیمت و موجودی کالا ها</li>
            </ol>
        </nav>
    </div>
    <div class="container">
        <div class="row">

            <div class="col-md-9">

                <div class="card">
                    <h5 class="card-header">بررسی قیمت و موجودی کالا ها </h5>
                    <div id="card-body" class="card-body">
                        <?php echo $result; ?>

                    </div>
                </div>


            </div>
            <div class="col-md-3">
                <?php echo $__env->make('admin.include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\MyWork\xampp\htdocs\cms\yasshop\resources\views/yasshop/warehousing/priceController.blade.php ENDPATH**/ ?>
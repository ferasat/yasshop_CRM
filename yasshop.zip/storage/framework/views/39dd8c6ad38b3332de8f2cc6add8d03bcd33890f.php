<?php $__env->startSection('title' , 'لیست محصولات'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <ul class="nav nav-tabs card-header-tabs">
                            <li class="nav-item">
                                <a class="nav-link active" href="<?php echo e(asset('/dashboard/product/')); ?>">محصولات</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(asset('/dashboard/product/new')); ?>">محصول جدید</a>
                            </li>
                        </ul>
                    </div>

                    <div class="card-body">
                        <div class="row">
                            <div class="desktop">
                                <table class="table ">
                                    <thead class="thead-dark">
                                    <tr>
                                        <th scope="col">نام محصول</th>
                                        <th scope="col"> کد محصول</th>
                                        <th scope="col">دسته بندی</th>
                                        <th scope="col">تصویر</th>
                                        <th scope="col">موجودی</th>
                                    </tr>
                                    </thead>
                                    <tbody>

                                    <?php for($x = 1 ; $x < $count  ; $x++): ?>
                                        
                                        
                                        <tr>
                                            <td><?php echo e($allProducts[$x]['product_name']); ?></td>
                                            <td><?php echo e($allProducts[$x]['sku']); ?> </td>
                                            <td> .. </td>
                                            <td style="padding: 0px;">
                                                <img src="<?php echo e($allProducts[$x]['product_pic']); ?>" alt="<?php echo e($allProducts[$x]['product_name']); ?>"
                                                         class="w100" style="width: 100px;height: 100px">

                                            </td>
                                            <td>
                                                <form action="<?php echo e(asset('/dashboard/product/adddell')); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="number" class="yasinput" name="mojodi"
                                                           value="<?php echo e($allProducts[$x]['value_real']); ?>">
                                                    <input type="hidden" name="id" value="<?php echo e($allProducts[$x]['value_real']); ?>">
                                                    <input type="submit" class="btn btn-dark" value="بروزرسانی">
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endfor; ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="mobail">
                                <div class="products-mobail">
                                    <div class="head-mobail">محصولات</div>
                                    <?php for($x = 1 ; $x < $count  ; $x++): ?>
                                    <div class="product-mobail">
                                        <div class="name-mobail"><?php echo e($allProducts[$x]['product_name']); ?> :</div>
                                        <div class="name-cat"><?php echo e($allProducts[$x]['sku']); ?></div>
                                        <div class="name-cat"><?php echo e($allProducts[$x]['sku']); ?></div>
                                        <div class="name-pic">
                                            <?php if( $allProducts[$x]['product_pic'] == null ): ?>
                                                ندارد
                                            <?php else: ?>
                                                <img src="<?php echo e($allProducts[$x]['product_pic']); ?>" alt="<?php echo e(''); ?>"
                                                     class="w100" style="width: 100px;height: 100px">
                                            <?php endif; ?>
                                        </div>
                                        <div class="name-price">
                                            <form action="<?php echo e(asset('/dashboard/product/adddell')); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="number" class="yasinput" name="mojodi"
                                                       value="<?php echo e($allProducts[$x]['value_real']); ?>">
                                                <input type="hidden" name="id" value="<?php echo e($allProducts[$x]['value_real']); ?>">
                                                <input type="submit" class="btn btn-dark" value="بروزرسانی">
                                            </form>
                                        </div>
                                    </div>
                                    <?php endfor; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\MyWork\xampp\htdocs\cms\yasshop\resources\views/yasshop/product/Product.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title' , 'لیست محصولات'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <ul class="nav nav-tabs card-header-tabs">
                            <li class="nav-item">
                                <a class="nav-link " href="<?php echo e(asset('/dashboard/orders/')); ?>">سفارشات</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link active" href="<?php echo e(asset('/dashboard/orders/new')); ?>">سفارش جدید</a>
                            </li>
                        </ul>
                    </div>

                    <div class="card-body">
                        <div class="row">
                            <div class="newCustomer">
                                <form action="<?php echo e(asset('/dashboard/orders/new')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-row">
                                        <div class="col-12">
                                            <label class="sr-only" for="inlineFormInputGroup">نام خریدار</label>
                                            <div class="input-group mb-2">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text">نام خریدار</div>
                                                </div>
                                                <input type="text" class="form-control" name="customer"
                                                       placeholder="نام خریدار را وارد کنید" required>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <input type="submit" class="btn btn-dark btn-w100" value="ساخت سبد خرید">
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\MyWork\xampp\htdocs\cms\yasshop\resources\views/yasshop/order/neworder.blade.php ENDPATH**/ ?>
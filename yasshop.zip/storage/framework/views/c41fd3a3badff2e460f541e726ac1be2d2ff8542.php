<?php $__env->startSection('title' , 'دیتابیس'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">

            <div class="col-md-9">
                <div class="card">
                    <div class="card-header">
                        Featured
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">بررسی و تعمییر جدول wp_postmeta</h5>

                        <a onclick="fixDB()" class="btn btn-primary">تعمییر کن</a>
                        <div id="result"></div>
                    </div>
                </div>

            </div>
            <div class="col-md-3">
                <?php echo $__env->make('admin.include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\MyWork\xampp\htdocs\cms\yasshop\resources\views/yasshop/admin/db.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title' , $title); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <ul class="nav nav-tabs card-header-tabs" style="padding: 0;">
                            <li class="nav-item">
                                <a class="nav-link " href="<?php echo e(asset('/dashboard/orders/')); ?>"> کل سفارشات</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(asset('/dashboard/orders/new')); ?>">سفارش جدید</a>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">بیشتر</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="<?php echo e(asset('/dashboard/orders/new')); ?>">سفارش جدید</a>
                                    <a class="dropdown-item" href="<?php echo e(asset(route('notShipped'))); ?>">ارسال نشده</a>
                                    <a class="dropdown-item" href="<?php echo e(asset(route('posted'))); ?>">ارسال شده</a>
                                    <a class="dropdown-item" href="<?php echo e(asset(route('deficit'))); ?>">کسری دار</a>
                                    <a class="dropdown-item" href="<?php echo e(asset(route('outStock'))); ?>">عدم موجودی</a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item" href="<?php echo e(asset(route('dashboard'))); ?>">پیشخوان</a>
                                    <a class="dropdown-item" href="<?php echo e(asset(route('warehousing'))); ?>">انبار</a>
                                </div>
                            </li>
                        </ul>
                    </div>

                    <div class="card-body">
                        <div class="row">
                            <div class="table-responsive">
                                <div class="col-12">
                                    <table class="table ">
                                        <thead class="thead-dark ">
                                        <tr>
                                            <th scope="col">نام مشتری</th>
                                            <th scope="col">نوع پرداخت</th>
                                            <th scope="col">مبلغ</th>
                                            <th scope="col">محل سفارش</th>
                                            <th scope="col">وضعیت</th>
                                            <th scope="col">یاداشت</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><a href="<?php echo e(asset('dashboard/orders/cart/'.$order -> id)); ?>"><?php echo e($order -> customer); ?></a></td>
                                                <td><?php echo e($order -> typeprice); ?></td>
                                                <td><?php echo e($order -> price); ?></td>
                                                <td><?php echo e($order -> srcsale); ?></td>
                                                <td><?php echo e($order -> status); ?></td>
                                                <td><?php echo e($order -> note); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\MyWork\xampp\htdocs\cms\yasshop\resources\views/yasshop/order/statusOrders.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title' , 'پیشخوان'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">

            <div class="col-md-9">
                <div class="card">
                    <div class="card-header">
                        خلاصه وضعیت فروشگاه
                    </div>

                    <div class="card-body">
                        <div class="row row-cols-1 row-cols-md-3">
                            <div class="col mb-4">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title">
                                            <button type="button" class="btn btn-primary">
                                                کسری انبار  <span class="badge badge-light"><?php echo e($numberP); ?></span>
                                            </button>

                                        </h5>
                                        <ul class="list-group list-group-flush">
                                            <?php echo $lessProducts; ?>

                                        </ul>
                                    </div>
                                </div>
                            </div>


                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <?php echo $__env->make('admin.include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\MyWork\xampp\htdocs\cms\yasshop\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title' , $title); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <div class="btn-group" role="group" aria-label="Button group with nested dropdown">


                            <div class="btn-group" role="group">
                                <button id="btnGroupDrop1" type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    دسترسی سریع
                                </button>
                                <div class="dropdown-menu" aria-labelledby="btnGroupDrop1">
                                    <a class="dropdown-item" href="<?php echo e(asset(route('orders'))); ?>"> همه سفارشات</a>
                                    <a class="dropdown-item" href="<?php echo e(asset(route('forBoxing'))); ?>"> برای بستبندی </a>
                                    <a class="dropdown-item" href="<?php echo e(asset(route('checkForPost'))); ?>">چک و آماده به ارسال </a>
                                    <a class="dropdown-item" href="<?php echo e(asset(route('posted'))); ?>">ارسال شده ها </a>
                                    <a class="dropdown-item" href="<?php echo e(asset(route('deficit'))); ?>">کسری دار</a>
                                    <a class="dropdown-item" href="#">Dropdown link</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card-body">

                        <div class="row">
                            <div class="table-responsive">
                                <div class="col-12">

                                    <table class="table ">
                                        <thead class="thead-dark ">
                                        <tr>
                                            <th scope="col">نام مشتری</th>
                                            <th scope="col">نوع پرداخت</th>
                                            <th scope="col">مبلغ</th>
                                            <th scope="col">محل سفارش</th>
                                            <th scope="col">یاداشت</th>
                                            <th scope="col">تایید</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <a href="<?php echo e(asset('dashboard/orders/cart/'.$order -> id)); ?>"><?php echo e($order -> customer); ?></a>
                                                </td>
                                                <td><?php echo e($order -> typeprice); ?></td>
                                                <td><?php echo e($order -> price); ?></td>
                                                <td><?php echo e($order -> srcsale); ?></td>
                                                <td><?php echo e($order -> note); ?></td>
                                                <td id="td-<?php echo e($order -> id); ?>">
                                                    <button id="sta-<?php echo e($order -> id); ?>" onclick="status(id='<?php echo e($order -> id); ?>',s=3)" type="button" class="btn btn-secondary btn-<?php echo e($order -> id); ?>" >تایید؟</button>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\MyWork\xampp\htdocs\cms\yasshop\resources\views/yasshop/order/checkForPost.blade.php ENDPATH**/ ?>
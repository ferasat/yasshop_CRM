<div class="sidebar">
    <div class="card" style="width: 18rem;">
        <div class="card-header">
            پشتیبانی
        </div>
        <ul class="list-group list-group-flush">
            <li class="list-group-item">
                <a href="{{ asset('/support') }}">دیدن همه درخواست ها</a>
            </li>
            <li class="list-group-item">
                <a href="{{ asset('/support/new') }}">درخواست جدید</a>
            </li>
        </ul>
    </div>
</div>

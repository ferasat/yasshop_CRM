<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Full_text_search extends Model
{
    //
}
